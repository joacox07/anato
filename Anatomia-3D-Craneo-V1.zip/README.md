# Anatomía 3D · Cráneo

Atlas web/PWA en español para estudiar un cráneo adulto, ATM, músculos masticadores y músculos de la mímica. La aplicación fue organizada a partir de dos apuntes de cátedra:

- `Clase 1.a. - cráneo, ATM, m masticadores 2.docx`
- `Clase 1.b. - Músculos de la Mímica.docx`

## Qué incluye

- 23 estructuras óseas seleccionables, ocultables, transparentables y aislables.
- Explosión del modelo y cortes sagital, coronal y transversal.
- Vistas anterior, lateral, superior e inferior.
- Buscador por nombre, sinónimo, categoría y contenido.
- Fichas que separan explícitamente **Cátedra** de **Información complementaria**.
- Sección prioritaria de forámenes y conductos con su contenido neurovascular.
- Suturas, fontanelas, cavidades, ATM, músculos masticadores y mímica.
- Animaciones didácticas de descenso, elevación, protrusión, retrusión, lateralidad, rotación y traslación mandibular.
- Modos de práctica: identificar, opción múltiple, tocar el modelo, tarjetas y cronómetro.
- Favoritas y “Me cuesta”, guardadas solo en el navegador del dispositivo.
- Exportación dinámica a USDZ para abrir el cráneo visible en AR Quick Look en iPhone.
- Manifest PWA para añadir la web a la pantalla de inicio.

## Ejecutar localmente

Requiere Node.js 22.

```bash
npm install
npm run dev
```

Abrir `http://localhost:3000`.

## Subir a Vercel

1. Descomprimir el ZIP.
2. Subir la carpeta a un repositorio de GitHub o importarla con Vercel CLI.
3. En Vercel, elegir el framework **Next.js** y dejar los comandos automáticos.
4. Desplegar. No requiere variables de entorno ni base de datos.

La realidad aumentada necesita HTTPS; el dominio de Vercel ya lo proporciona. En iPhone, abrir la web en Safari y tocar `Ver en AR`.

## Alcance y precisión

El texto de cátedra se conserva como capa principal. Las ampliaciones anatómicas se muestran en un bloque diferente y no sustituyen silenciosamente las formulaciones de los apuntes. Los puntos 3D finos solo aparecen cuando fueron cargados en esta malla; para el resto, la aplicación enfoca el hueso correspondiente y lo declara en la ficha.

Las bandas musculares son un esquema topográfico para relacionar origen, inserción y acción; no son una segmentación volumétrica diagnóstica. La animación de ATM es didáctica y no representa una simulación biomecánica individual.

## Modelo y licencia

La geometría ósea deriva de **BodyParts3D — The Database Center for Life Science**, bajo licencia CC BY-SA 2.1 Japan. Consultar [MODEL-LICENSE.md](MODEL-LICENSE.md).

Esta herramienta apoya el estudio, pero no reemplaza la corrección docente, la bibliografía oficial ni el reconocimiento en piezas anatómicas.
