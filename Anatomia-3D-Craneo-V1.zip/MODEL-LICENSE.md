# Modelo anatómico

Los archivos OBJ de `public/models/skull/` provienen de:

> BodyParts3D, © The Database Center for Life Science, licensed under Creative Commons Attribution-ShareAlike 2.1 Japan.

- Descripción: https://dbarchive.biosciencedbc.jp/en/bodyparts3d/desc.html
- Descarga: https://dbarchive.biosciencedbc.jp/en/bodyparts3d/download.html
- Licencia: https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html
- Publicación: Mitsuhashi N, Fujieda K, Tamura T, Kawamoto S, Takagi T, Okubo K. *BodyParts3D: 3D structure database for anatomical concepts*. Nucleic Acids Research. 2009;37(Database issue):D782–D785. DOI: 10.1093/nar/gkn613.

La selección, agrupamiento, color y presentación web constituyen una adaptación. La geometría derivada debe conservar la atribución y compartirse bajo los términos compatibles de CC BY-SA 2.1 Japan.
