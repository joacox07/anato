"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Bone,
  Box,
  Brain,
  Camera,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Eye,
  EyeOff,
  Focus,
  Info,
  Layers3,
  Menu,
  Moon,
  Move3d,
  Pause,
  Play,
  Search,
  Sparkles,
  Star,
  Sun,
  Target,
  Undo2,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BONE_BY_ID,
  BONE_DEFINITIONS,
  CATEGORIES,
  ITEM_BY_ID,
  SOURCE_LINKS,
  STUDY_ITEMS,
  type BoneId,
  type Category,
  type StudyItem,
} from "./anatomy-data";
import { SkullViewer, type CutPlane, type JawMovement, type MuscleLayer, type SkullViewerHandle } from "./skull-viewer";

type PracticeMode = "identify" | "multiple" | "touch" | "cards" | "timed";

const modeLabels: Record<PracticeMode, string> = {
  identify: "Identificar",
  multiple: "Opciones",
  touch: "Tocar modelo",
  cards: "Tarjetas",
  timed: "Cronómetro",
};

function normalize(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function useStoredSet(key: string) {
  const [value, setValue] = useState<Set<string>>(new Set());
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      try {
        setValue(new Set(JSON.parse(localStorage.getItem(key) ?? "[]")));
      } catch {
        setValue(new Set());
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, [key]);
  const toggle = (id: string) => {
    setValue((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      localStorage.setItem(key, JSON.stringify(Array.from(next)));
      return next;
    });
  };
  return [value, toggle] as const;
}

function SourceBadge({ page }: { page: string }) {
  return (
    <div className="source-badge">
      <span>CÁTEDRA</span>
      <small>{page}</small>
    </div>
  );
}

function DetailCard({
  item,
  favorite,
  difficult,
  onFavorite,
  onDifficult,
  onFocus,
}: {
  item: StudyItem;
  favorite: boolean;
  difficult: boolean;
  onFavorite: () => void;
  onDifficult: () => void;
  onFocus: () => void;
}) {
  return (
    <article className="detail-card">
      <div className="detail-card__topline">
        <Badge variant="outline">{item.category}</Badge>
        {item.examPriority && <span className={`priority priority--${item.examPriority.toLowerCase()}`}>{item.examPriority}</span>}
      </div>
      <h2>{item.name}</h2>
      {item.aliases?.length ? <p className="aliases">También: {item.aliases.join(" · ")}</p> : null}

      <div className="detail-actions">
        <Button type="button" variant={favorite ? "secondary" : "outline"} size="sm" onClick={onFavorite}>
          <Star className={favorite ? "fill-current" : ""} /> Favorita
        </Button>
        <Button type="button" variant={difficult ? "secondary" : "outline"} size="sm" onClick={onDifficult}>
          <AlertTriangle /> Me cuesta
        </Button>
        {item.targetBone && (
          <Button type="button" variant="outline" size="sm" onClick={onFocus}>
            <Focus /> Enfocar
          </Button>
        )}
      </div>

      <section className="faculty-note">
        <SourceBadge page={item.facultyPage} />
        <p>{item.faculty}</p>
      </section>

      {item.extra && (
        <section className="extra-note">
          <div className="extra-note__title"><Sparkles /> Información complementaria</div>
          <p>{item.extra.replace(/^Información complementaria( verificada)?\s*[—:-]?\s*/i, "")}</p>
        </section>
      )}

      {item.relations?.length ? (
        <section className="relations">
          <h3>Relaciones clave</h3>
          <div>{item.relations.map((relation) => <span key={relation}>{relation}</span>)}</div>
        </section>
      ) : null}

      {item.anchor ? (
        <p className="anchor-note"><Target /> El punto de referencia 3D fue cargado para orientación directa.</p>
      ) : item.category === "Forámenes y conductos" ? (
        <p className="anchor-note anchor-note--muted"><Info /> Se enfoca el hueso correspondiente; no se dibuja un punto fino si su coordenada no fue validada en esta malla.</p>
      ) : null}
    </article>
  );
}

function BoneControls({
  hidden,
  transparent,
  selected,
  onSelect,
  onHide,
  onTransparent,
}: {
  hidden: Set<BoneId>;
  transparent: Set<BoneId>;
  selected?: BoneId;
  onSelect: (id: BoneId) => void;
  onHide: (id: BoneId) => void;
  onTransparent: (id: BoneId) => void;
}) {
  return (
    <div className="bone-controls">
      {BONE_DEFINITIONS.map((bone) => (
        <div className={`bone-row ${selected === bone.id ? "bone-row--selected" : ""}`} key={bone.id}>
          <button type="button" className="bone-row__name" onClick={() => onSelect(bone.id)}>
            <span style={{ background: bone.color }} />
            {bone.name}
          </button>
          <button type="button" title={hidden.has(bone.id) ? "Mostrar" : "Ocultar"} aria-label={hidden.has(bone.id) ? `Mostrar ${bone.name}` : `Ocultar ${bone.name}`} onClick={() => onHide(bone.id)}>
            {hidden.has(bone.id) ? <EyeOff /> : <Eye />}
          </button>
          <button type="button" title="Alternar transparencia" aria-label={`Alternar transparencia de ${bone.name}`} className={transparent.has(bone.id) ? "active" : ""} onClick={() => onTransparent(bone.id)}>
            <Layers3 />
          </button>
        </div>
      ))}
    </div>
  );
}

function Explorer({
  selectedId,
  onSelect,
  hidden,
  transparent,
  selectedBone,
  onSelectBone,
  onHideBone,
  onTransparentBone,
  favorites,
  difficult,
}: {
  selectedId: string;
  onSelect: (item: StudyItem) => void;
  hidden: Set<BoneId>;
  transparent: Set<BoneId>;
  selectedBone?: BoneId;
  onSelectBone: (id: BoneId) => void;
  onHideBone: (id: BoneId) => void;
  onTransparentBone: (id: BoneId) => void;
  favorites: Set<string>;
  difficult: Set<string>;
}) {
  const [openCategory, setOpenCategory] = useState<Category>("Huesos");
  return (
    <aside className="explorer-panel">
      <div className="panel-heading">
        <div><small>ATLAS</small><h2>Estructuras</h2></div>
        <Badge variant="secondary">{STUDY_ITEMS.length}</Badge>
      </div>
      <div className="category-list">
        {CATEGORIES.map((category) => {
          const items = STUDY_ITEMS.filter((item) => item.category === category);
          const open = openCategory === category;
          return (
            <section className="category-block" key={category}>
              <button type="button" className="category-trigger" onClick={() => setOpenCategory(open ? "Huesos" : category)} aria-expanded={open}>
                <span>{category}</span><span className="category-count">{items.length}</span><ChevronDown className={open ? "rotate" : ""} />
              </button>
              {open && category === "Huesos" ? (
                <BoneControls hidden={hidden} transparent={transparent} selected={selectedBone} onSelect={onSelectBone} onHide={onHideBone} onTransparent={onTransparentBone} />
              ) : open ? (
                <div className="study-item-list">
                  {items.map((item) => (
                    <button type="button" key={item.id} className={selectedId === item.id ? "active" : ""} onClick={() => onSelect(item)}>
                      <span>{item.name}</span>
                      <span className="item-flags">
                        {favorites.has(item.id) && <Star className="fill-current" />}
                        {difficult.has(item.id) && <AlertTriangle />}
                      </span>
                    </button>
                  ))}
                </div>
              ) : null}
            </section>
          );
        })}
      </div>
    </aside>
  );
}

function PracticePanel({
  mode,
  setMode,
  item,
  options,
  answer,
  setAnswer,
  revealed,
  setRevealed,
  next,
  flashFlipped,
  setFlashFlipped,
  seconds,
  running,
  setRunning,
  touchResult,
}: {
  mode: PracticeMode;
  setMode: (mode: PracticeMode) => void;
  item: StudyItem;
  options: StudyItem[];
  answer?: string;
  setAnswer: (id: string) => void;
  revealed: boolean;
  setRevealed: (value: boolean) => void;
  next: () => void;
  flashFlipped: boolean;
  setFlashFlipped: (value: boolean) => void;
  seconds: number;
  running: boolean;
  setRunning: (value: boolean) => void;
  touchResult?: "ok" | "wrong";
}) {
  const correct = answer === item.id;
  return (
    <aside className="practice-panel">
      <div className="panel-heading"><div><small>PRÁCTICA</small><h2>Modo examen</h2></div><Target /></div>
      <div className="practice-modes">
        {(Object.keys(modeLabels) as PracticeMode[]).map((key) => (
          <button type="button" key={key} className={mode === key ? "active" : ""} onClick={() => setMode(key)}>{modeLabels[key]}</button>
        ))}
      </div>

      {mode === "cards" ? (
        <button type="button" className={`flashcard ${flashFlipped ? "flipped" : ""}`} onClick={() => setFlashFlipped(!flashFlipped)}>
          <span className="flashcard__eyebrow">{flashFlipped ? "RESPUESTA" : item.category}</span>
          <strong>{flashFlipped ? item.name : item.faculty}</strong>
          <span>{flashFlipped ? item.facultyPage : "Tocá para revelar"}</span>
        </button>
      ) : (
        <div className="question-card">
          <div className="question-card__meta">
            <Badge variant="outline">{item.category}</Badge>
            {mode === "timed" && <span className={seconds <= 10 ? "timer danger" : "timer"}><Clock3 /> {seconds}s</span>}
          </div>
          <p className="question-label">
            {mode === "touch" ? "Tocá esta estructura en el modelo:" : mode === "identify" ? "¿Qué estructura corresponde a esta definición?" : "Elegí la respuesta correcta:"}
          </p>
          {mode === "touch" ? <h3>{item.name}</h3> : <blockquote>{item.faculty}</blockquote>}

          {mode === "touch" ? (
            <div className="touch-instruction">
              <Move3d /> Girá el cráneo y tocá el hueso.
              {touchResult === "ok" && <span className="answer-ok"><Check /> Correcto</span>}
              {touchResult === "wrong" && <span className="answer-wrong"><X /> Probá otra vez</span>}
            </div>
          ) : (
            <div className="option-list">
              {options.map((option) => {
                const chosen = answer === option.id;
                const showCorrect = revealed && option.id === item.id;
                return (
                  <button type="button" key={option.id} disabled={revealed} className={`${chosen ? "chosen" : ""} ${showCorrect ? "correct" : ""} ${revealed && chosen && !correct ? "wrong" : ""}`} onClick={() => { setAnswer(option.id); setRevealed(true); }}>
                    {option.name}
                    {showCorrect && <Check />}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      <div className="practice-footer">
        {mode === "timed" && (
          <Button type="button" variant="outline" size="sm" onClick={() => setRunning(!running)}>{running ? <Pause /> : <Play />}{running ? "Pausar" : "Iniciar"}</Button>
        )}
        <Button type="button" size="sm" onClick={next}>Siguiente</Button>
      </div>
      <p className="session-note">Los resultados de la sesión no se guardan.</p>
    </aside>
  );
}

export default function AtlasClient() {
  const viewerRef = useRef<SkullViewerHandle>(null);
  const [mode, setMode] = useState<"study" | "practice">("study");
  const [selectedId, setSelectedId] = useState("region-neurocranium");
  const selectedItem = ITEM_BY_ID[selectedId] ?? STUDY_ITEMS[0];
  const [selectedBone, setSelectedBone] = useState<BoneId | undefined>();
  const [hiddenBones, setHiddenBones] = useState<Set<BoneId>>(new Set());
  const [transparentBones, setTransparentBones] = useState<Set<BoneId>>(new Set());
  const [isolatedBone, setIsolatedBone] = useState<BoneId | undefined>();
  const [explode, setExplode] = useState(0);
  const [cutPlane, setCutPlane] = useState<CutPlane>("none");
  const [cutOffset, setCutOffset] = useState(0);
  const [cutInverted, setCutInverted] = useState(false);
  const [showLabels, setShowLabels] = useState(true);
  const [movement, setMovement] = useState<JawMovement>("none");
  const [animateMovement, setAnimateMovement] = useState(false);
  const [muscleLayer, setMuscleLayer] = useState<MuscleLayer>("none");
  const [loaded, setLoaded] = useState(0);
  const [total, setTotal] = useState(1);
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [structuresOpen, setStructuresOpen] = useState(false);
  const [controlsOpen, setControlsOpen] = useState(false);
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [arOpen, setArOpen] = useState(false);
  const [arStatus, setArStatus] = useState("");
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [favorites, toggleFavorite] = useStoredSet("atlas-craneo:favorites");
  const [difficult, toggleDifficult] = useStoredSet("atlas-craneo:difficult");

  const [practiceMode, setPracticeMode] = useState<PracticeMode>("identify");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState<string>();
  const [revealed, setRevealed] = useState(false);
  const [flashFlipped, setFlashFlipped] = useState(false);
  const [seconds, setSeconds] = useState(60);
  const [running, setRunning] = useState(false);
  const [touchResult, setTouchResult] = useState<"ok" | "wrong">();

  const practicePool = useMemo(() => STUDY_ITEMS.filter((item) => item.examPriority !== "Normal" && (practiceMode !== "touch" || item.targetBone)), [practiceMode]);
  const question = practicePool[questionIndex % practicePool.length] ?? STUDY_ITEMS[0];
  const options = useMemo(() => {
    const sameCategory = STUDY_ITEMS.filter((item) => item.category === question.category && item.id !== question.id);
    const offset = questionIndex % Math.max(sameCategory.length, 1);
    return [question, ...sameCategory.slice(offset, offset + 3), ...sameCategory.slice(0, Math.max(0, 3 - sameCategory.slice(offset, offset + 3).length))]
      .slice(0, 4)
      .sort((a, b) => (a.id.charCodeAt(0) + questionIndex) % 7 - (b.id.charCodeAt(0) + questionIndex) % 7);
  }, [question, questionIndex]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  useEffect(() => {
    if (!running || practiceMode !== "timed") return;
    const interval = window.setInterval(() => {
      setSeconds((value) => {
        if (value <= 1) {
          setRunning(false);
          setRevealed(true);
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [running, practiceMode]);

  const results = useMemo(() => {
    const needle = normalize(query.trim());
    if (!needle) return [];
    return STUDY_ITEMS.filter((item) => normalize([item.name, ...(item.aliases ?? []), item.category, item.faculty].join(" ")).includes(needle)).slice(0, 12);
  }, [query]);

  const selectItem = (item: StudyItem) => {
    setSelectedId(item.id);
    setMuscleLayer(item.category === "Masticadores" ? "mastication" : item.category === "Mímica" ? "mimic" : "none");
    if (item.targetBone) {
      setSelectedBone(item.targetBone);
      window.setTimeout(() => viewerRef.current?.focusBone(item.targetBone!), 60);
    }
    setSearchOpen(false);
    setStructuresOpen(false);
  };

  const selectBone = (boneId: BoneId, fromPractice = false) => {
    if (mode === "practice" && practiceMode === "touch" && fromPractice) {
      setTouchResult(boneId === question.targetBone ? "ok" : "wrong");
      if (boneId === question.targetBone) setSelectedBone(boneId);
      return;
    }
    setSelectedBone(boneId);
    setSelectedId(`bone-${boneId}`);
  };

  const toggleBoneSet = (setter: React.Dispatch<React.SetStateAction<Set<BoneId>>>, id: BoneId) => setter((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const resetView = () => {
    setHiddenBones(new Set());
    setTransparentBones(new Set());
    setIsolatedBone(undefined);
    setExplode(0);
    setCutPlane("none");
    setCutOffset(0);
    setMovement("none");
    setAnimateMovement(false);
    setMuscleLayer("none");
    viewerRef.current?.setView("reset");
  };

  const nextQuestion = () => {
    setQuestionIndex((value) => value + 1);
    setAnswer(undefined);
    setRevealed(false);
    setFlashFlipped(false);
    setTouchResult(undefined);
    setSeconds(60);
  };

  const movementButtons: { id: JawMovement; label: string }[] = [
    { id: "depression", label: "Descenso" },
    { id: "elevation", label: "Elevación" },
    { id: "protrusion", label: "Protrusión" },
    { id: "retrusion", label: "Retrusión" },
    { id: "left", label: "Lateralidad izq." },
    { id: "right", label: "Lateralidad der." },
    { id: "rotation", label: "Rotación" },
    { id: "translation", label: "Traslación" },
  ];

  const controlsPanel = (
    <div className="controls-panel">
      <section>
        <div className="control-title"><span>Etiquetas óseas</span><Switch checked={showLabels} onCheckedChange={setShowLabels} /></div>
        <p>Las líneas se anclan al centro geométrico del segmento óseo.</p>
        <div className="segmented muscle-selector">
          <button type="button" className={muscleLayer === "mastication" ? "active" : ""} onClick={() => setMuscleLayer(muscleLayer === "mastication" ? "none" : "mastication")}>Masticadores</button>
          <button type="button" className={muscleLayer === "mimic" ? "active" : ""} onClick={() => setMuscleLayer(muscleLayer === "mimic" ? "none" : "mimic")}>Mímica</button>
        </div>
      </section>
      <section>
        <div className="control-title"><span>Explosión</span><b>{explode}%</b></div>
        <Slider value={[explode]} min={0} max={100} step={1} onValueChange={(value) => setExplode(value[0])} />
      </section>
      <section>
        <div className="control-title"><span>Planos de corte</span><button type="button" onClick={() => setCutInverted(!cutInverted)}>Invertir</button></div>
        <div className="segmented">
          {(["none", "sagittal", "coronal", "transverse"] as CutPlane[]).map((cut) => <button type="button" key={cut} className={cutPlane === cut ? "active" : ""} onClick={() => setCutPlane(cut)}>{cut === "none" ? "Sin corte" : cut === "sagittal" ? "Sagital" : cut === "coronal" ? "Coronal" : "Transversal"}</button>)}
        </div>
        {cutPlane !== "none" && <Slider value={[cutOffset]} min={-65} max={65} step={1} onValueChange={(value) => setCutOffset(value[0])} />}
      </section>
      <section>
        <div className="control-title"><span>Atajos de disección</span></div>
        <div className="control-grid">
          <Button variant="outline" size="sm" onClick={() => { setCutPlane("transverse"); setCutInverted(true); setCutOffset(-28); }}>Retirar calvaria</Button>
          <Button variant="outline" size="sm" onClick={() => { setMovement("depression"); setAnimateMovement(false); }}>Abrir mandíbula</Button>
          <Button variant="outline" size="sm" onClick={() => { setCutPlane("sagittal"); setCutInverted(false); setCutOffset(0); }}>Hemisección</Button>
          <Button variant="outline" size="sm" onClick={resetView}><Undo2 /> Restablecer</Button>
        </div>
      </section>
      <section>
        <div className="control-title"><span>Movimientos ATM</span><span className="didactic-tag">animación didáctica</span></div>
        <div className="movement-grid">
          {movementButtons.map((item) => <button type="button" key={item.id} className={movement === item.id ? "active" : ""} onClick={() => setMovement(item.id)}>{item.label}</button>)}
        </div>
        <label className="animate-toggle"><Switch checked={animateMovement} onCheckedChange={setAnimateMovement} /> Repetir movimiento</label>
      </section>
    </div>
  );

  return (
    <main className="atlas-shell">
      <header className="app-header">
        <div className="brand">
          <div className="brand-mark"><Bone /></div>
          <div><span>ANATOMÍA 3D</span><strong>Cráneo · Cátedra</strong></div>
        </div>
        <Tabs value={mode} onValueChange={(value) => setMode(value as "study" | "practice")} className="mode-tabs">
          <TabsList>
            <TabsTrigger value="study"><Brain /> Estudiar</TabsTrigger>
            <TabsTrigger value="practice"><Target /> Practicar</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="header-actions">
          <Button type="button" variant="ghost" size="icon" className="mobile-only" onClick={() => setStructuresOpen(true)} aria-label="Abrir estructuras"><Menu /></Button>
          <div className="search-wrap">
            <Search />
            <input value={query} onChange={(event) => { setQuery(event.target.value); setSearchOpen(true); }} onFocus={() => setSearchOpen(true)} placeholder="Buscar hueso, foramen, músculo…" aria-label="Buscar estructura" />
            {query && <button type="button" onClick={() => setQuery("")} aria-label="Limpiar búsqueda"><X /></button>}
            {searchOpen && query && (
              <div className="search-results">
                {results.length ? results.map((item) => (
                  <button type="button" key={item.id} onClick={() => selectItem(item)}>
                    <span>{item.name}<small>{item.aliases?.[0]}</small></span><Badge variant="outline">{item.category}</Badge>
                  </button>
                )) : <p>No se encontraron coincidencias.</p>}
              </div>
            )}
          </div>
          <Button type="button" variant="ghost" size="icon" onClick={() => setTheme(theme === "light" ? "dark" : "light")} aria-label="Cambiar tema">{theme === "light" ? <Moon /> : <Sun />}</Button>
          <Button type="button" variant="ghost" size="icon" onClick={() => setSourcesOpen(true)} aria-label="Fuentes y criterio"><CircleHelp /></Button>
        </div>
      </header>

      <div className="safety-strip"><AlertTriangle /> <span><b>Orden de lectura:</b> primero aparece lo que dice la cátedra; toda ampliación o corrección está separada como “Información complementaria”.</span></div>

      <div className={`workspace ${mode === "practice" ? "workspace--practice" : ""}`}>
        {mode === "study" ? (
          <Explorer selectedId={selectedId} onSelect={selectItem} hidden={hiddenBones} transparent={transparentBones} selectedBone={selectedBone} onSelectBone={selectBone} onHideBone={(id) => toggleBoneSet(setHiddenBones, id)} onTransparentBone={(id) => toggleBoneSet(setTransparentBones, id)} favorites={favorites} difficult={difficult} />
        ) : (
          <PracticePanel mode={practiceMode} setMode={(value) => { setPracticeMode(value); nextQuestion(); }} item={question} options={options} answer={answer} setAnswer={setAnswer} revealed={revealed} setRevealed={setRevealed} next={nextQuestion} flashFlipped={flashFlipped} setFlashFlipped={setFlashFlipped} seconds={seconds} running={running} setRunning={setRunning} touchResult={touchResult} />
        )}

        <section className="viewer-stage">
          <SkullViewer
            ref={viewerRef}
            selectedBone={mode === "practice" && practiceMode === "identify" ? question.targetBone : selectedBone}
            hiddenBones={hiddenBones}
            transparentBones={transparentBones}
            isolatedBone={isolatedBone}
            explode={explode}
            cutPlane={cutPlane}
            cutOffset={cutOffset}
            cutInverted={cutInverted}
            showLabels={mode === "practice" && practiceMode !== "cards" ? false : showLabels}
            marker={mode === "study" ? selectedItem.anchor : undefined}
            movement={movement}
            animateMovement={animateMovement}
            muscleLayer={muscleLayer}
            onSelectBone={(id) => selectBone(id, true)}
            onLoadProgress={(value, max) => { setLoaded(value); setTotal(max); }}
            onARStatus={setArStatus}
          />
          {loaded < total && <div className="loading-model"><span style={{ width: `${(loaded / total) * 100}%` }} /><b>Cargando anatomía {loaded}/{total}</b></div>}
          <div className="viewer-topbar">
            <div className="view-buttons">
              <button type="button" onClick={() => viewerRef.current?.setView("anterior")}>Anterior</button>
              <button type="button" onClick={() => viewerRef.current?.setView("lateral")}>Lateral</button>
              <button type="button" onClick={() => viewerRef.current?.setView("superior")}>Superior</button>
              <button type="button" onClick={() => viewerRef.current?.setView("inferior")}>Inferior</button>
            </div>
            <div className="viewer-actions">
              <Button type="button" variant="secondary" size="sm" onClick={() => setControlsOpen(true)} className="mobile-only"><Box /> Herramientas</Button>
              <Button type="button" variant="secondary" size="sm" onClick={() => setArOpen(true)}><Camera /> Ver en AR</Button>
            </div>
          </div>
          <div className="viewer-bottom-controls desktop-controls">{controlsPanel}</div>
          <div className="selected-pill">
            <span style={{ background: selectedBone ? BONE_BY_ID[selectedBone].color : "#8b8b8b" }} />
            {selectedBone ? BONE_BY_ID[selectedBone].name : "Cráneo completo"}
            {selectedBone && <button type="button" onClick={() => setIsolatedBone(isolatedBone === selectedBone ? undefined : selectedBone)}>{isolatedBone ? "Mostrar todo" : "Aislar"}</button>}
          </div>
        </section>

        {mode === "study" ? (
          <aside className="detail-panel">
            <DetailCard item={selectedItem} favorite={favorites.has(selectedItem.id)} difficult={difficult.has(selectedItem.id)} onFavorite={() => toggleFavorite(selectedItem.id)} onDifficult={() => toggleDifficult(selectedItem.id)} onFocus={() => selectedItem.targetBone && viewerRef.current?.focusBone(selectedItem.targetBone)} />
          </aside>
        ) : (
          <aside className="practice-reference">
            <div className="reference-card">
              <small>AYUDA DE SESIÓN</small>
              <h2>{revealed || touchResult === "ok" ? question.name : "Respuesta oculta"}</h2>
              <p>{revealed || touchResult === "ok" ? question.faculty : "Respondé primero para mostrar la explicación de la cátedra."}</p>
              {(revealed || touchResult === "ok") && <SourceBadge page={question.facultyPage} />}
            </div>
          </aside>
        )}
      </div>

      <Sheet open={structuresOpen} onOpenChange={setStructuresOpen}>
        <SheetContent side="left" className="mobile-sheet wide-sheet"><SheetHeader><SheetTitle>Estructuras</SheetTitle><SheetDescription>Navegá el programa de la cátedra.</SheetDescription></SheetHeader><Explorer selectedId={selectedId} onSelect={selectItem} hidden={hiddenBones} transparent={transparentBones} selectedBone={selectedBone} onSelectBone={selectBone} onHideBone={(id) => toggleBoneSet(setHiddenBones, id)} onTransparentBone={(id) => toggleBoneSet(setTransparentBones, id)} favorites={favorites} difficult={difficult} /></SheetContent>
      </Sheet>

      <Sheet open={controlsOpen} onOpenChange={setControlsOpen}>
        <SheetContent side="bottom" className="mobile-sheet controls-sheet"><SheetHeader><SheetTitle>Herramientas 3D</SheetTitle><SheetDescription>Segmentación, cortes y movimiento.</SheetDescription></SheetHeader>{controlsPanel}</SheetContent>
      </Sheet>

      <Sheet open={arOpen} onOpenChange={setArOpen}>
        <SheetContent side="bottom" className="ar-sheet">
          <SheetHeader><SheetTitle>Realidad aumentada</SheetTitle><SheetDescription>Colocá el cráneo adulto sobre una superficie con AR Quick Look.</SheetDescription></SheetHeader>
          <div className="ar-content">
            <div className="ar-icon"><Camera /></div>
            <div>
              <h3>Preparado para iPhone</h3>
              <p>El archivo se genera con los huesos que estén visibles, su transparencia, explosión y posición mandibular actuales. En Quick Look podés moverlo, girarlo y cambiar su escala.</p>
              <div className="ar-warning"><Info /> Los rótulos HTML y las fichas interactivas permanecen en el visor web: iOS Quick Look no los conserva dentro del USDZ. Volvé a la web para consultar nombres y definiciones.</div>
              {arStatus && <p className="ar-status">{arStatus}</p>}
            </div>
            <Button type="button" size="lg" onClick={() => viewerRef.current?.exportAR()}><Camera /> Generar y abrir en AR</Button>
          </div>
        </SheetContent>
      </Sheet>

      <Sheet open={sourcesOpen} onOpenChange={setSourcesOpen}>
        <SheetContent side="right" className="sources-sheet">
          <SheetHeader><SheetTitle>Fuentes y criterio</SheetTitle><SheetDescription>Cómo leer cada capa de información.</SheetDescription></SheetHeader>
          <div className="source-list">
            <div className="criterion-card"><SourceBadge page="material principal" /><p>La redacción de las fichas prioriza el contenido entregado por la cátedra. Una posible inconsistencia no se corrige silenciosamente.</p></div>
            <div className="criterion-card extra"><Sparkles /><p>Las ampliaciones anatómicas se muestran aparte y sirven para contraste, no para sustituir la respuesta esperada por la profesora.</p></div>
            {SOURCE_LINKS.map((source) => <div className="source-item" key={source.name}><strong>{source.name}</strong><p>{source.detail}</p>{source.url && <a href={source.url} target="_blank" rel="noreferrer">Abrir fuente</a>}</div>)}
            <p className="medical-disclaimer">Herramienta de estudio. La geometría segmentada y las animaciones no reemplazan la bibliografía oficial, una pieza anatómica ni la corrección docente.</p>
          </div>
        </SheetContent>
      </Sheet>
    </main>
  );
}
