export type BoneId =
  | "frontal"
  | "parietal-r"
  | "parietal-l"
  | "occipital"
  | "temporal-r"
  | "temporal-l"
  | "sphenoid"
  | "ethmoid"
  | "maxilla-r"
  | "maxilla-l"
  | "zygomatic-r"
  | "zygomatic-l"
  | "nasal-r"
  | "nasal-l"
  | "lacrimal-r"
  | "lacrimal-l"
  | "palatine-r"
  | "palatine-l"
  | "concha-r"
  | "concha-l"
  | "vomer"
  | "mandible"
  | "hyoid";

export type Category =
  | "Huesos"
  | "Regiones y cavidades"
  | "Suturas y fontanelas"
  | "Forámenes y conductos"
  | "ATM"
  | "Masticadores"
  | "Mímica";

export type Vec3 = [number, number, number];

export interface BoneDefinition {
  id: BoneId;
  name: string;
  side?: "Derecho" | "Izquierdo";
  aliases: string[];
  files: string[];
  color: string;
  group: "Neurocráneo" | "Viscerocráneo" | "Asociado";
}

export interface StudyItem {
  id: string;
  name: string;
  aliases?: string[];
  category: Category;
  faculty: string;
  facultyPage: string;
  extra?: string;
  relations?: string[];
  targetBone?: BoneId;
  anchor?: Vec3;
  examPriority?: "Esencial" | "Alta" | "Normal";
}

export const BONE_DEFINITIONS: BoneDefinition[] = [
  { id: "frontal", name: "Frontal", aliases: ["hueso frontal"], files: ["FJ3200.obj"], color: "#d8b39a", group: "Neurocráneo" },
  { id: "parietal-r", name: "Parietal derecho", side: "Derecho", aliases: ["hueso parietal"], files: ["FJ3380.obj"], color: "#e0c2a8", group: "Neurocráneo" },
  { id: "parietal-l", name: "Parietal izquierdo", side: "Izquierdo", aliases: ["hueso parietal"], files: ["FJ3274.obj"], color: "#e0c2a8", group: "Neurocráneo" },
  { id: "occipital", name: "Occipital", aliases: ["hueso occipital"], files: ["FJ3309.obj"], color: "#c8a78e", group: "Neurocráneo" },
  { id: "temporal-r", name: "Temporal derecho", side: "Derecho", aliases: ["hueso temporal", "peñasco"], files: ["FJ3386.obj"], color: "#d4aa8f", group: "Neurocráneo" },
  { id: "temporal-l", name: "Temporal izquierdo", side: "Izquierdo", aliases: ["hueso temporal", "peñasco"], files: ["FJ3281.obj"], color: "#d4aa8f", group: "Neurocráneo" },
  { id: "sphenoid", name: "Esfenoides", aliases: ["hueso esfenoides"], files: ["FJ3394.obj"], color: "#cf9d82", group: "Neurocráneo" },
  { id: "ethmoid", name: "Etmoides", aliases: ["hueso etmoides"], files: ["FJ3199.obj"], color: "#e2b79b", group: "Neurocráneo" },
  { id: "maxilla-r", name: "Maxilar derecho", side: "Derecho", aliases: ["maxilar superior"], files: ["FJ3375.obj"], color: "#efd0b4", group: "Viscerocráneo" },
  { id: "maxilla-l", name: "Maxilar izquierdo", side: "Izquierdo", aliases: ["maxilar superior"], files: ["FJ3269.obj"], color: "#efd0b4", group: "Viscerocráneo" },
  { id: "zygomatic-r", name: "Cigomático derecho", side: "Derecho", aliases: ["malar"], files: ["FJ3392.obj"], color: "#e6ba9a", group: "Viscerocráneo" },
  { id: "zygomatic-l", name: "Cigomático izquierdo", side: "Izquierdo", aliases: ["malar"], files: ["FJ3287.obj"], color: "#e6ba9a", group: "Viscerocráneo" },
  { id: "nasal-r", name: "Nasal derecho", side: "Derecho", aliases: ["propio de la nariz"], files: ["FJ3378.obj"], color: "#f0c8aa", group: "Viscerocráneo" },
  { id: "nasal-l", name: "Nasal izquierdo", side: "Izquierdo", aliases: ["propio de la nariz"], files: ["FJ3272.obj"], color: "#f0c8aa", group: "Viscerocráneo" },
  { id: "lacrimal-r", name: "Lagrimal derecho", side: "Derecho", aliases: ["unguis"], files: ["FJ3371.obj"], color: "#d7c0a9", group: "Viscerocráneo" },
  { id: "lacrimal-l", name: "Lagrimal izquierdo", side: "Izquierdo", aliases: ["unguis"], files: ["FJ3265.obj"], color: "#d7c0a9", group: "Viscerocráneo" },
  { id: "palatine-r", name: "Palatino derecho", side: "Derecho", aliases: ["hueso palatino"], files: ["FJ3379.obj"], color: "#c99f88", group: "Viscerocráneo" },
  { id: "palatine-l", name: "Palatino izquierdo", side: "Izquierdo", aliases: ["hueso palatino"], files: ["FJ3273.obj"], color: "#c99f88", group: "Viscerocráneo" },
  { id: "concha-r", name: "Cornete inferior derecho", side: "Derecho", aliases: ["concha nasal inferior"], files: ["FJ3369.obj"], color: "#d8ab91", group: "Viscerocráneo" },
  { id: "concha-l", name: "Cornete inferior izquierdo", side: "Izquierdo", aliases: ["concha nasal inferior"], files: ["FJ3263.obj"], color: "#d8ab91", group: "Viscerocráneo" },
  { id: "vomer", name: "Vómer", aliases: ["hueso vómer"], files: ["FJ3395.obj"], color: "#c8967d", group: "Viscerocráneo" },
  { id: "mandible", name: "Mandíbula", aliases: ["maxilar inferior"], files: ["FJ3289.obj"], color: "#e4b494", group: "Viscerocráneo" },
  { id: "hyoid", name: "Hioides", aliases: ["hueso hioides"], files: ["FJ2772.obj"], color: "#c88f75", group: "Asociado" },
];

const boneNotes: Partial<Record<BoneId, string>> = {
  frontal: "Hueso impar que participa de la calota; aparece por delante de los parietales y forma parte de la fosa craneal anterior.",
  "parietal-r": "Hueso par de la calota, ubicado entre el frontal y el occipital.",
  "parietal-l": "Hueso par de la calota, ubicado entre el frontal y el occipital.",
  occipital: "Hueso impar posterior de la calota y componente principal de la zona posterior de la base.",
  "temporal-r": "Hueso par lateral del neurocráneo. Su porción petrosa participa del límite entre las fosas media y posterior.",
  "temporal-l": "Hueso par lateral del neurocráneo. Su porción petrosa participa del límite entre las fosas media y posterior.",
  sphenoid: "Hueso de la base; sus alas mayores participan lateralmente de la calota y sus alas menores limitan las fosas anterior y media.",
  ethmoid: "Participa del techo y la pared medial de las fosas nasales; su lámina cribosa forma parte de la fosa craneal anterior.",
  "maxilla-r": "El maxilar superior es el hueso central, par, del macizo facial; ambos maxilares se unen en la línea media por las apófisis palatinas.",
  "maxilla-l": "El maxilar superior es el hueso central, par, del macizo facial; ambos maxilares se unen en la línea media por las apófisis palatinas.",
  "zygomatic-r": "Hueso par del viscerocráneo; el apunte usa también el sinónimo malar.",
  "zygomatic-l": "Hueso par del viscerocráneo; el apunte usa también el sinónimo malar.",
  "nasal-r": "Hueso par del viscerocráneo; forma la porción superior de la pirámide nasal.",
  "nasal-l": "Hueso par del viscerocráneo; forma la porción superior de la pirámide nasal.",
  "lacrimal-r": "Hueso par del viscerocráneo; el apunte usa también el sinónimo unguis y lo vincula con la vía lagrimal.",
  "lacrimal-l": "Hueso par del viscerocráneo; el apunte usa también el sinónimo unguis y lo vincula con la vía lagrimal.",
  "palatine-r": "Hueso par del viscerocráneo. Forma el cuarto posterior del piso nasal y parte del paladar duro.",
  "palatine-l": "Hueso par del viscerocráneo. Forma el cuarto posterior del piso nasal y parte del paladar duro.",
  "concha-r": "El cornete inferior es un hueso independiente; sobresale en la pared lateral de la fosa nasal.",
  "concha-l": "El cornete inferior es un hueso independiente; sobresale en la pared lateral de la fosa nasal.",
  vomer: "Hueso impar del viscerocráneo; integra la porción posteroinferior del tabique nasal óseo.",
  mandible: "Único hueso móvil del cráneo; es impar, mediano y simétrico. Presenta cuerpo y dos ramas.",
  hyoid: "Hueso impar, mediano y simétrico, palpable a nivel cervical anterior (C3); no se articula con ningún otro hueso.",
};

export const BONE_STUDY_ITEMS: StudyItem[] = BONE_DEFINITIONS.map((bone) => ({
  id: `bone-${bone.id}`,
  name: bone.name,
  aliases: bone.aliases,
  category: "Huesos",
  faculty: boneNotes[bone.id] ?? `Hueso incluido por la cátedra dentro del ${bone.group.toLowerCase()}.`,
  facultyPage: bone.id === "mandible" ? "Clase 1.a, pp. 31–32" : bone.id === "hyoid" ? "Clase 1.a, p. 33" : "Clase 1.a, pp. 1–16",
  relations: [bone.group, bone.side ?? "Impar"],
  targetBone: bone.id,
  examPriority: bone.id === "mandible" ? "Esencial" : "Alta",
}));

const regions: StudyItem[] = [
  { id: "region-neurocranium", name: "Neurocráneo", category: "Regiones y cavidades", faculty: "Cavidad ósea que aloja y protege al encéfalo. Se divide en calota o calvaria y base de cráneo.", facultyPage: "Clase 1.a, p. 1", relations: ["Calvaria", "Base de cráneo"], examPriority: "Esencial" },
  { id: "region-viscerocranium", name: "Viscerocráneo", aliases: ["esqueleto facial", "macizo facial"], category: "Regiones y cavidades", faculty: "Parte anterior del cráneo donde se aloja gran parte de los órganos de los sentidos, el inicio de los aparatos digestivo y respiratorio y el sistema masticatorio.", facultyPage: "Clase 1.a, pp. 1, 14–16", relations: ["Maxilar", "Cigomático", "Nasal", "Lagrimal", "Palatino", "Cornete inferior", "Vómer", "Mandíbula"], examPriority: "Esencial" },
  { id: "region-calvaria", name: "Calota o calvaria", category: "Regiones y cavidades", faculty: "Se ubica por encima de una línea imaginaria que pasa sobre arcos supraciliares, arcos cigomáticos y protuberancia occipital externa. Es convexa exocranealmente y cóncava endocranealmente.", facultyPage: "Clase 1.a, p. 2", relations: ["Frontal", "Parietales", "Occipital", "Temporales", "Alas mayores del esfenoides"], examPriority: "Alta" },
  { id: "fossa-anterior", name: "Fosa craneal anterior", category: "Regiones y cavidades", faculty: "Primer piso de la base interna; aloja el lóbulo frontal. Su límite posterior incluye el surco prequiasmático y el borde posterior de las alas menores del esfenoides.", facultyPage: "Clase 1.a, pp. 6–7", relations: ["Frontal", "Etmoides", "Esfenoides"], targetBone: "frontal", examPriority: "Alta" },
  { id: "fossa-middle", name: "Fosa craneal media", category: "Regiones y cavidades", faculty: "Segundo piso de la base interna; aloja el lóbulo temporal. Está limitada posteriormente por el borde superior de la porción petrosa del temporal y las apófisis clinoides posteriores.", facultyPage: "Clase 1.a, pp. 6–9", relations: ["Esfenoides", "Temporal"], targetBone: "sphenoid", examPriority: "Alta" },
  { id: "fossa-posterior", name: "Fosa craneal posterior", category: "Regiones y cavidades", faculty: "Tercer piso de la base interna; aloja cerebelo y tronco encefálico. La pared posterior es principalmente temporal y occipital.", facultyPage: "Clase 1.a, pp. 6–9", relations: ["Temporal", "Occipital"], targetBone: "occipital", examPriority: "Alta" },
  { id: "orbit", name: "Cavidad orbitaria", category: "Regiones y cavidades", faculty: "Contiene globo ocular, glándula lagrimal, músculos extrínsecos, nervio óptico, nervios motores oculares, ramas del trigémino y vasos orbitarios.", facultyPage: "Clase 1.a, pp. 17–21", relations: ["Globo ocular", "II, III, IV, V y VI pares craneales", "Vía lagrimal"], targetBone: "sphenoid", examPriority: "Alta" },
  { id: "nasal-cavity", name: "Fosas nasales", category: "Regiones y cavidades", faculty: "Calientan, humidifican y filtran el aire. Los cornetes generan turbulencia y prolongan el contacto con la mucosa nasal.", facultyPage: "Clase 1.a, pp. 22–27", relations: ["Coanas", "Tabique nasal", "Cornetes", "Meatos"], targetBone: "ethmoid", examPriority: "Alta" },
  { id: "choanae", name: "Coanas", aliases: ["orificios nasales posteriores"], category: "Regiones y cavidades", faculty: "Forámenes posteriores de las fosas nasales que comunican con la faringe. Límites: vómer medial, lámina medial pterigoidea lateral, cuerpo del esfenoides superior y palatino inferior.", facultyPage: "Clase 1.a, p. 23", relations: ["Vómer", "Esfenoides", "Palatino"], targetBone: "vomer", examPriority: "Alta" },
  { id: "paranasal-sinuses", name: "Senos paranasales", category: "Regiones y cavidades", faculty: "Cavidades maxilares, frontales y esfenoidales, o celdillas etmoidales, que desembocan en los meatos. El apunte les atribuye aligerar el cráneo, resonancia vocal, compensación térmica y producción de moco.", facultyPage: "Clase 1.a, pp. 28–29", relations: ["Frontal", "Maxilar", "Esfenoides", "Etmoides"], targetBone: "maxilla-r", examPriority: "Alta" },
  { id: "oral-cavity", name: "Cavidad bucal", category: "Regiones y cavidades", faculty: "Espacio desde los labios hasta el istmo de las fauces. El paladar duro es maxilar y palatino; el piso está formado por músculos suprahioideos.", facultyPage: "Clase 1.a, pp. 29–30", relations: ["Paladar duro", "Dientes", "Lengua", "Glándulas sublinguales"], targetBone: "maxilla-r", examPriority: "Normal" },
  { id: "adult-dentition", name: "Dentición adulta (esquema)", aliases: ["dientes"], category: "Regiones y cavidades", faculty: "El apunte enumera los dientes dentro del contenido de la cavidad bucal, sin desarrollar su morfología en esta clase.", facultyPage: "Clase 1.a, p. 30", extra: "Información complementaria: la malla muestra coronas simplificadas solo para orientar las arcadas; no debe usarse para estudiar anatomía dental fina.", relations: ["Maxilar", "Mandíbula", "Proceso alveolar"], targetBone: "maxilla-r", examPriority: "Normal" },
];

const suturesAndFontanelles: StudyItem[] = [
  { id: "suture-coronal", name: "Sutura coronal", category: "Suturas y fontanelas", faculty: "Unión fibrosa transversal entre el frontal y ambos parietales.", facultyPage: "Clase 1.a, pp. 4–5", relations: ["Frontal", "Parietales"], targetBone: "frontal", examPriority: "Alta" },
  { id: "suture-sagittal", name: "Sutura sagital", category: "Suturas y fontanelas", faculty: "Unión fibrosa en la línea media entre ambos parietales.", facultyPage: "Clase 1.a, pp. 4–5", relations: ["Parietal derecho", "Parietal izquierdo"], targetBone: "parietal-r", examPriority: "Alta" },
  { id: "suture-lambdoid", name: "Sutura lambdoidea", category: "Suturas y fontanelas", faculty: "Unión fibrosa entre parietales y occipital.", facultyPage: "Clase 1.a, pp. 4–5", relations: ["Parietales", "Occipital"], targetBone: "occipital", examPriority: "Alta" },
  { id: "suture-squamous", name: "Sutura escamosa", category: "Suturas y fontanelas", faculty: "Unión fibrosa lateral entre el parietal y la escama del temporal.", facultyPage: "Clase 1.a, pp. 4–5", relations: ["Parietal", "Temporal"], targetBone: "temporal-r", examPriority: "Alta" },
  { id: "fontanelle-general", name: "Fontanelas", category: "Suturas y fontanelas", faculty: "Espacios entre los huesos membranosos de la calvaria fetal. Al cerrarse y osificarse gradualmente después del nacimiento dejan definidos los puntos de unión y las suturas.", facultyPage: "Clase 1.a, p. 4", extra: "Información complementaria: las fontanelas son un contenido pediátrico incluido por la cátedra; el modelo 3D de esta entrega representa un cráneo adulto ya osificado.", examPriority: "Esencial" },
  { id: "fontanelle-anterior", name: "Fontanela anterior", aliases: ["bregmática", "bregma"], category: "Suturas y fontanelas", faculty: "Espacio membranoso anterior en la confluencia de suturas coronal y sagital.", facultyPage: "Clase 1.a, p. 4", extra: "Información complementaria: es la mayor; suele cerrarse aproximadamente entre los 18 y 24 meses, con variación normal.", relations: ["Frontal", "Parietales", "Sutura coronal", "Sutura sagital"], targetBone: "frontal", examPriority: "Esencial" },
  { id: "fontanelle-posterior", name: "Fontanela posterior", aliases: ["lambdática", "lambda"], category: "Suturas y fontanelas", faculty: "Espacio membranoso posterior en la confluencia de suturas sagital y lambdoidea.", facultyPage: "Clase 1.a, p. 4", extra: "Información complementaria: suele cerrarse durante los primeros meses de vida.", relations: ["Parietales", "Occipital"], targetBone: "occipital", examPriority: "Esencial" },
  { id: "fontanelle-sphenoidal", name: "Fontanela esfenoidal", aliases: ["anterolateral"], category: "Suturas y fontanelas", faculty: "Fontanela par ubicada en la región anterolateral de la calvaria.", facultyPage: "Clase 1.a, p. 4", relations: ["Frontal", "Parietal", "Temporal", "Esfenoides"], targetBone: "sphenoid", examPriority: "Alta" },
  { id: "fontanelle-mastoid", name: "Fontanela mastoidea", aliases: ["posterolateral"], category: "Suturas y fontanelas", faculty: "Fontanela par ubicada en la región posterolateral de la calvaria.", facultyPage: "Clase 1.a, p. 4", relations: ["Parietal", "Temporal", "Occipital"], targetBone: "temporal-r", examPriority: "Alta" },
];

const foramina: StudyItem[] = [
  { id: "foramen-cecum", name: "Foramen ciego", category: "Forámenes y conductos", faculty: "Referencia de la fosa craneal anterior, entre frontal y etmoides.", facultyPage: "Clase 1.a, p. 9", extra: "Información complementaria — contenido: vena emisaria hacia el seno sagital superior cuando el conducto es permeable.", targetBone: "ethmoid", examPriority: "Esencial" },
  { id: "cribriform-foramina", name: "Forámenes de la lámina cribosa", aliases: ["agujeros cribosos"], category: "Forámenes y conductos", faculty: "Múltiples orificios de la lámina cribosa del etmoides en la fosa craneal anterior.", facultyPage: "Clase 1.a, p. 9", extra: "Información complementaria — contenido: filetes del nervio olfatorio (I) y pequeños vasos.", targetBone: "ethmoid", examPriority: "Esencial" },
  { id: "optic-canal", name: "Conducto óptico", category: "Forámenes y conductos", faculty: "Comunicación entre la fosa craneal media y la órbita, en el esfenoides.", facultyPage: "Clase 1.a, pp. 9, 17–20", extra: "Información complementaria — contenido: nervio óptico (II), arteria oftálmica y fibras simpáticas acompañantes.", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "superior-orbital-fissure", name: "Fisura orbitaria superior", aliases: ["hendidura esfenoidal"], category: "Forámenes y conductos", faculty: "Hendidura del esfenoides entre sus alas mayor y menor; comunica fosa craneal media y órbita.", facultyPage: "Clase 1.a, pp. 9, 17–20", extra: "Información complementaria — contenido principal: nervios III, IV y VI; ramas lagrimal, frontal y nasociliar de V1; vena oftálmica superior y fibras simpáticas. La vena oftálmica inferior puede atravesarla.", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "foramen-rotundum", name: "Foramen redondo", category: "Forámenes y conductos", faculty: "Orificio del ala mayor del esfenoides en la fosa craneal media.", facultyPage: "Clase 1.a, p. 9", extra: "Información complementaria — contenido: nervio maxilar (V2).", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "foramen-ovale", name: "Foramen oval", category: "Forámenes y conductos", faculty: "Orificio del ala mayor del esfenoides visible en las bases interna y externa.", facultyPage: "Clase 1.a, pp. 9, 12", extra: "Información complementaria — contenido: nervio mandibular (V3), arteria meníngea accesoria, vena emisaria y, de manera variable, nervio petroso menor.", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "foramen-spinosum", name: "Foramen espinoso", category: "Forámenes y conductos", faculty: "Orificio del ala mayor del esfenoides, posterolateral al foramen oval.", facultyPage: "Clase 1.a, pp. 9, 12", extra: "Información complementaria — contenido: arteria y vena meníngeas medias y ramo meníngeo de V3 (nervio espinoso).", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "foramen-lacerum", name: "Foramen lacerum", aliases: ["agujero rasgado"], category: "Forámenes y conductos", faculty: "Referencia de la base craneal media, visible interna y externamente.", facultyPage: "Clase 1.a, pp. 9, 12", extra: "Información complementaria — está ocupado por fibrocartílago. La carótida interna pasa sobre su borde superior, no a través de su luz. Los nervios petrosos mayor y profundo cruzan su región superior y forman el nervio del conducto pterigoideo; también pasan pequeñas venas emisarias y ramas meníngeas.", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "carotid-canal", name: "Conducto carotídeo", category: "Forámenes y conductos", faculty: "Conducto de la porción petrosa del temporal; su abertura externa se reconoce en la zona media de la base externa.", facultyPage: "Clase 1.a, pp. 9, 12", extra: "Información complementaria — contenido: arteria carótida interna, plexo simpático carotídeo interno y plexo venoso.", targetBone: "temporal-r", examPriority: "Esencial" },
  { id: "internal-acoustic-meatus", name: "Conducto auditivo interno", aliases: ["meato acústico interno"], category: "Forámenes y conductos", faculty: "Orificio de la cara posterior de la porción petrosa del temporal, en la fosa craneal posterior.", facultyPage: "Clase 1.a, p. 9", extra: "Información complementaria — contenido: nervios facial (VII) y vestibulococlear (VIII), arteria laberíntica y venas laberínticas.", targetBone: "temporal-r", examPriority: "Esencial" },
  { id: "jugular-foramen", name: "Foramen yugular", category: "Forámenes y conductos", faculty: "Abertura entre temporal y occipital; relacionada con la fosa yugular en la base externa.", facultyPage: "Clase 1.a, pp. 9, 12", extra: "Información complementaria — contenido principal: nervios IX, X y XI; seno sigmoideo que continúa como yugular interna; seno petroso inferior y ramas meníngeas arteriales.", targetBone: "temporal-r", examPriority: "Esencial" },
  { id: "hypoglossal-canal", name: "Conducto del hipogloso", category: "Forámenes y conductos", faculty: "Conducto del occipital próximo al foramen magno, en la fosa craneal posterior.", facultyPage: "Clase 1.a, p. 9", extra: "Información complementaria — contenido: nervio hipogloso (XII), plexo venoso y rama meníngea de la arteria faríngea ascendente.", targetBone: "occipital", examPriority: "Esencial" },
  { id: "foramen-magnum", name: "Foramen magno", category: "Forámenes y conductos", faculty: "Gran abertura del occipital visible en la base interna y en la zona posterior de la base externa.", facultyPage: "Clase 1.a, pp. 9, 13", extra: "Información complementaria — contenido principal: unión bulbo-medular con meninges, arterias vertebrales, arterias espinales anterior y posteriores, raíces espinales del XI y plexos venosos.", targetBone: "occipital", examPriority: "Esencial" },
  { id: "stylomastoid-foramen", name: "Foramen estilomastoideo", category: "Forámenes y conductos", faculty: "Abertura del temporal entre las apófisis estiloides y mastoides, en la zona media de la base externa.", facultyPage: "Clase 1.a, p. 12", extra: "Información complementaria — contenido: salida del nervio facial (VII) y arteria estilomastoidea.", targetBone: "temporal-r", examPriority: "Esencial" },
  { id: "mastoid-foramen", name: "Foramen mastoideo", category: "Forámenes y conductos", faculty: "Pequeño foramen de la región mastoidea-occipital.", facultyPage: "Clase 1.a, base externa", extra: "Información complementaria — contenido: vena emisaria mastoidea y rama meníngea de la arteria occipital; su posición y tamaño son variables.", targetBone: "temporal-r", examPriority: "Alta" },
  { id: "condylar-canal", name: "Conducto condíleo", category: "Forámenes y conductos", faculty: "Referencia de la zona posterior de la base externa, próxima al cóndilo occipital.", facultyPage: "Clase 1.a, p. 13", extra: "Información complementaria — contenido habitual: vena emisaria condílea; puede ser inconstante.", targetBone: "occipital", examPriority: "Esencial" },
  { id: "incisive-canal", name: "Conducto incisivo", aliases: ["foramen incisivo"], category: "Forámenes y conductos", faculty: "Orificio anterior del paladar duro, detrás de los incisivos superiores.", facultyPage: "Clase 1.a, base externa y cavidad bucal", extra: "Información complementaria — contenido: nervios nasopalatinos y vasos anastomóticos entre territorios esfenopalatino y palatino mayor.", targetBone: "maxilla-r", examPriority: "Alta" },
  { id: "greater-palatine-foramen", name: "Foramen palatino mayor", category: "Forámenes y conductos", faculty: "Abertura posterolateral del paladar duro.", facultyPage: "Clase 1.a, base externa", extra: "Información complementaria — contenido: nervio y vasos palatinos mayores.", targetBone: "palatine-r", examPriority: "Alta" },
  { id: "lesser-palatine-foramina", name: "Forámenes palatinos menores", category: "Forámenes y conductos", faculty: "Pequeñas aberturas posteriores al foramen palatino mayor.", facultyPage: "Clase 1.a, base externa", extra: "Información complementaria — contenido: nervios y vasos palatinos menores.", targetBone: "palatine-r", examPriority: "Alta" },
  { id: "sphenopalatine-foramen", name: "Foramen esfenopalatino", category: "Forámenes y conductos", faculty: "Comunicación de la pared lateral de las fosas nasales.", facultyPage: "Clase 1.a, fosas nasales", extra: "Información complementaria — contenido: vasos esfenopalatinos, nervio nasopalatino y nervios nasales posteriores superiores laterales.", targetBone: "palatine-r", examPriority: "Alta" },
  { id: "inferior-orbital-fissure", name: "Fisura orbitaria inferior", category: "Forámenes y conductos", faculty: "Hendidura del piso y la pared lateral de la órbita.", facultyPage: "Clase 1.a, pp. 17–20", extra: "Información complementaria — contenido: nervios infraorbitario y cigomático (V2), vasos infraorbitarios, conexiones venosas y ramos orbitarios del ganglio pterigopalatino.", targetBone: "maxilla-r", examPriority: "Esencial" },
  { id: "infraorbital-foramen", name: "Foramen infraorbitario", category: "Forámenes y conductos", faculty: "Abertura anterior del maxilar, inferior al reborde orbitario.", facultyPage: "Clase 1.a, pp. 16–20", extra: "Información complementaria — contenido: nervio y vasos infraorbitarios.", targetBone: "maxilla-r", anchor: [-30, -181, 1505], examPriority: "Esencial" },
  { id: "supraorbital-foramen", name: "Foramen o incisura supraorbitaria", category: "Forámenes y conductos", faculty: "Referencia del reborde supraorbitario del frontal.", facultyPage: "Clase 1.a, calota y órbita", extra: "Información complementaria — contenido: nervio y vasos supraorbitarios.", targetBone: "frontal", anchor: [-27, -176, 1555], examPriority: "Alta" },
  { id: "ethmoidal-foramina", name: "Forámenes etmoidales anterior y posterior", category: "Forámenes y conductos", faculty: "Pequeñas comunicaciones en la pared medial de la órbita.", facultyPage: "Clase 1.a, pp. 17–20", extra: "Información complementaria — contenido: nervios y vasos etmoidales anterior y posterior, respectivamente.", targetBone: "ethmoid", examPriority: "Alta" },
  { id: "nasolacrimal-canal", name: "Conducto nasolagrimal", category: "Forámenes y conductos", faculty: "Parte de la vía lagrimal; comunica el saco lagrimal con la cavidad nasal.", facultyPage: "Clase 1.a, p. 21", extra: "Información complementaria — contenido: conducto nasolagrimal, que desemboca en el meato nasal inferior.", targetBone: "lacrimal-r", examPriority: "Alta" },
  { id: "mandibular-foramen", name: "Foramen mandibular", category: "Forámenes y conductos", faculty: "Se observa en la cara medial de la rama mandibular; por delante está la língula o espina de Spix y desde allí parte el surco milohioideo.", facultyPage: "Clase 1.a, pp. 31–32", extra: "Información complementaria — contenido: nervio, arteria y vena alveolares inferiores.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "mental-foramen", name: "Foramen mentoniano", category: "Forámenes y conductos", faculty: "Se ubica en la cara lateral del cuerpo de la mandíbula.", facultyPage: "Clase 1.a, pp. 31–32", extra: "Información complementaria — contenido: nervio y vasos mentonianos.", targetBone: "mandible", anchor: [-25, -170, 1453], examPriority: "Esencial" },
  { id: "pterygoid-canal", name: "Conducto pterigoideo", aliases: ["conducto vidiano"], category: "Forámenes y conductos", faculty: "Conducto de la región pterigoidea del esfenoides.", facultyPage: "Clase 1.a, base de cráneo", extra: "Información complementaria — contenido: nervio, arteria y vena del conducto pterigoideo.", targetBone: "sphenoid", examPriority: "Alta" },
  { id: "external-acoustic-meatus", name: "Conducto auditivo externo", aliases: ["meato acústico externo"], category: "Forámenes y conductos", faculty: "Referencia del temporal en la zona media de la base externa; también marca el límite imaginario entre neurocráneo y viscerocráneo.", facultyPage: "Clase 1.a, pp. 1, 12", extra: "Información complementaria: conduce hacia la membrana timpánica; no transmite un paquete neurovascular equivalente a los forámenes de la base.", targetBone: "temporal-r", examPriority: "Alta" },
];

const atm: StudyItem[] = [
  { id: "tmj-surfaces", name: "ATM: superficies articulares", category: "ATM", faculty: "Articulación entre mandíbula y temporal. Temporal: fosa mandibular cóncava por detrás y tubérculo articular convexo por delante. Mandíbula: cóndilo con eje mayor transversal.", facultyPage: "Clase 1.a, p. 35", relations: ["Temporal", "Cóndilo mandibular", "Fosa mandibular", "Tubérculo articular"], targetBone: "mandible", examPriority: "Esencial" },
  { id: "tmj-disc", name: "Disco articular de la ATM", category: "ATM", faculty: "Fibrocartílago ovalado y bicóncavo de tejido conectivo denso. Se une a la cabeza condilar por sus polos medial y lateral y a la cápsula en toda su periferia; divide cavidades suprameniscal e inframeniscal.", facultyPage: "Clase 1.a, p. 36", extra: "Información complementaria: el compartimento inferior participa sobre todo en rotación y el superior en traslación.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "tmj-capsule", name: "Cápsula de la ATM", category: "ATM", faculty: "Se inserta alrededor de las superficies articulares; posteriormente, en la fosa mandibular, llega a la fisura timpanoescamosa. Disco y cápsula se desplazan juntos.", facultyPage: "Clase 1.a, p. 36", targetBone: "temporal-r", examPriority: "Alta" },
  { id: "tmj-intrinsic-ligaments", name: "Ligamentos intrínsecos", category: "ATM", faculty: "La cápsula está reforzada por un ligamento lateral externo y otro medial menos potente.", facultyPage: "Clase 1.a, p. 36", targetBone: "mandible", examPriority: "Alta" },
  { id: "sphenomandibular-ligament", name: "Ligamento esfenomandibular", category: "ATM", faculty: "Desde la espina del esfenoides hasta la língula o espina de Spix de la mandíbula.", facultyPage: "Clase 1.a, p. 37", targetBone: "sphenoid", examPriority: "Alta" },
  { id: "stylomandibular-ligament", name: "Ligamento estilomandibular", category: "ATM", faculty: "Desde la apófisis estiloides hasta el ángulo de la mandíbula.", facultyPage: "Clase 1.a, p. 37", targetBone: "temporal-r", examPriority: "Alta" },
  { id: "pterygomandibular-ligament", name: "Ligamento pterigomaxilar", aliases: ["pterigomandibular"], category: "ATM", faculty: "Desde el gancho de la lámina interna de la apófisis pterigoides hasta el borde alveolar mandibular, detrás del tercer molar.", facultyPage: "Clase 1.a, p. 37", extra: "Información complementaria: en terminología anatómica suele denominarse rafe pterigomandibular; se conserva primero el nombre usado por la cátedra.", targetBone: "mandible", examPriority: "Alta" },
  { id: "tmj-classification", name: "Clasificación de la ATM", category: "ATM", faculty: "El apunte formula la pregunta de clasificación, sin consignar una respuesta textual en la diapositiva.", facultyPage: "Clase 1.a, p. 38", extra: "Información complementaria verificada: articulación sinovial, compleja por su disco, bicondílea y funcionalmente gínglimo-artrodial porque combina rotación y traslación.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "tmj-rotation", name: "Rotación mandibular", category: "ATM", faculty: "Movimiento inicial de apertura y cierre representado en la secuencia de la cátedra.", facultyPage: "Clase 1.a, pp. 38, 41", extra: "Información complementaria: predomina en el compartimento inframeniscal alrededor de un eje transversal.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "tmj-translation", name: "Traslación mandibular", category: "ATM", faculty: "Desplazamiento anterior del complejo cóndilo-disco sobre el tubérculo articular durante la apertura amplia y la protrusión.", facultyPage: "Clase 1.a, pp. 38, 41", extra: "Información complementaria: predomina en el compartimento suprameniscal.", targetBone: "mandible", examPriority: "Esencial" },
];

const mastication: StudyItem[] = [
  { id: "muscle-masseter", name: "Masetero", category: "Masticadores", faculty: "Plano profundo: arco cigomático a cara lateral de la rama. Plano superficial: dos tercios anteriores del arco cigomático al ángulo mandibular.", facultyPage: "Clase 1.a, p. 39", extra: "Información complementaria: eleva la mandíbula; la porción superficial ayuda a protruir y la profunda puede colaborar en retrusión. Inervación: nervio masetérico, V3.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "muscle-temporalis", name: "Temporal", category: "Masticadores", faculty: "Desde la línea temporal superior, ocupando la fosa temporal, hacia la apófisis coronoides de la mandíbula y el ligamento pterigomandibular.", facultyPage: "Clase 1.a, p. 39", extra: "Información complementaria: eleva la mandíbula; las fibras posteriores colaboran en retrusión. Inervación: nervios temporales profundos, V3.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "muscle-lateral-pterygoid", name: "Pterigoideo lateral", category: "Masticadores", faculty: "Desde cara lateral de la lámina lateral pterigoidea y ala mayor del esfenoides. Fascículo superior a cápsula y disco de ATM; fascículo inferior a fosa pterigoidea mandibular.", facultyPage: "Clase 1.a, p. 40", extra: "Información complementaria: protruye y ayuda a descender la mandíbula; la contracción unilateral produce diducción contralateral. Inervación: nervio para pterigoideo lateral, V3.", targetBone: "sphenoid", examPriority: "Esencial" },
  { id: "muscle-medial-pterygoid", name: "Pterigoideo medial", category: "Masticadores", faculty: "Se extiende desde la fosa pterigoidea hasta la cara medial del ángulo mandibular.", facultyPage: "Clase 1.a, p. 40", extra: "Información complementaria: eleva y ayuda a protruir la mandíbula; unilateralmente contribuye a diducción contralateral. Inervación: nervio para pterigoideo medial, V3.", targetBone: "mandible", examPriority: "Esencial" },
  { id: "jaw-opening", name: "Apertura mandibular", category: "Masticadores", faculty: "El descenso o depresión mandibular depende de los músculos suprahioideos y de la gravedad.", facultyPage: "Clase 1.a, p. 39", targetBone: "mandible", examPriority: "Alta" },
  { id: "jaw-closing", name: "Cierre mandibular", category: "Masticadores", faculty: "El ascenso u oclusión depende de cuatro músculos: dos laterales y dos mediales a la rama mandibular.", facultyPage: "Clase 1.a, p. 39", relations: ["Masetero", "Temporal", "Pterigoideo lateral", "Pterigoideo medial"], targetBone: "mandible", examPriority: "Alta" },
];

const mimic = (id: string, name: string, group: string, action: string, page: string, extra?: string): StudyItem => ({
  id,
  name,
  category: "Mímica",
  faculty: `${group}. ${action}`,
  facultyPage: `Clase 1.b, p. ${page}`,
  extra,
  examPriority: "Alta",
});

const facialExpression: StudyItem[] = [
  { id: "mimic-general", name: "Músculos de la mímica", aliases: ["músculos de la expresión facial"], category: "Mímica", faculty: "Músculos superficiales de expresión facial y comunicación no verbal. La mayoría tiene inserción cutánea. Inervación motora principal: facial (VII); sensibilidad de la piel: trigémino (V).", facultyPage: "Clase 1.b, p. 1", relations: ["Epicraneal", "Palpebral", "Nasal", "Bucolabial", "Auricular y cervical"], examPriority: "Esencial" },
  mimic("mimic-occipitofrontalis", "Occipitofrontal", "Grupo epicraneal", "Eleva las cejas y arruga la frente.", "2"),
  mimic("mimic-temporoparietalis", "Temporoparietal", "Grupo epicraneal", "Moviliza el pabellón auricular.", "2"),
  mimic("mimic-orbicularis-oculi", "Orbicular del ojo", "Grupo palpebral", "Porción palpebral: cierra los párpados. Porción orbitaria: cierra con fuerza todo el ojo.", "3"),
  mimic("mimic-corrugator", "Corrugador superciliar", "Grupo palpebral", "Produce pliegues verticales en la frente y aproxima las cejas.", "3"),
  mimic("mimic-depressor-supercilii", "Depresor superciliar", "Grupo palpebral", "Desciende las cejas y produce pliegues en la raíz de la nariz.", "3"),
  mimic("mimic-nasalis", "Nasal", "Grupo nasal", "Porción transversa: comprime el orificio nasal. Porción alar: dilata el orificio nasal.", "4"),
  mimic("mimic-procerus", "Prócer", "Grupo nasal", "Tracciona hacia abajo la piel de la frente y produce pliegues transversales en la raíz nasal; frunce el ceño.", "4"),
  mimic("mimic-depressor-septi", "Depresor del tabique nasal", "Grupo nasal", "Desciende el tabique y contribuye al estrechamiento de las narinas.", "4"),
  mimic("mimic-orbicularis-oris", "Orbicular de la boca", "Grupo bucolabial", "Cierra la boca —gesto de beso— y actúa como verdadero esfínter bucal.", "5"),
  mimic("mimic-depressor-anguli", "Depresor del ángulo de la boca", "Grupo bucolabial", "Desciende la comisura labial ipsilateral.", "5"),
  mimic("mimic-transversus-menti", "Transverso del mentón", "Grupo bucolabial", "Une ambos depresores del ángulo de la boca por debajo del mentón.", "5"),
  mimic("mimic-risorius", "Risorio", "Grupo bucolabial", "Retrae lateralmente la comisura, ensancha la hendidura bucal y produce la ‘sonrisa falsa’ sin elevar las comisuras.", "5"),
  mimic("mimic-zygomaticus-major", "Cigomático mayor", "Grupo bucolabial", "Eleva y desplaza superolateralmente la comisura; participa en la ‘sonrisa verdadera’.", "5"),
  mimic("mimic-zygomaticus-minor", "Cigomático menor", "Grupo bucolabial", "Eleva y desplaza superolateralmente la comisura; participa en la ‘sonrisa verdadera’ al igual que el mayor.", "5"),
  mimic("mimic-levator-labii-alaeque", "Elevador del labio superior y del ala de la nariz", "Grupo bucolabial", "Eleva el labio superior y el ala nasal.", "5"),
  mimic("mimic-depressor-labii", "Depresor del labio inferior", "Grupo bucolabial", "Desciende el labio inferior.", "5"),
  mimic("mimic-levator-anguli", "Elevador del ángulo de la boca", "Grupo bucolabial", "Eleva el ángulo de la boca.", "5"),
  mimic("mimic-buccinator", "Buccinador", "Grupo bucolabial", "Participa en risa y llanto; mueve el alimento desde el vestíbulo durante la masticación y evita el atrapamiento de mucosa.", "5"),
  mimic("mimic-mentalis", "Mentoniano", "Grupo bucolabial", "Lleva la piel del mentón hacia arriba.", "5"),
  mimic("mimic-levator-palpebrae", "Elevador del párpado superior", "Mención del apunte", "El texto general lo presenta como excepción inervada por el III par y también lo enumera dentro del grupo bucolabial.", "1 y 5", "Información complementaria — posible inconsistencia del material: el elevador del párpado superior es un músculo orbitario, no bucolabial. Es probable que en la lista se haya querido mencionar al elevador del labio superior. Se conserva la formulación de la cátedra para estudio.") ,
  mimic("mimic-auricular-anterior", "Auricular anterior", "Grupo auricular", "Carece de valor funcional según el apunte.", "7"),
  mimic("mimic-auricular-superior", "Auricular superior", "Grupo auricular", "Carece de valor funcional según el apunte.", "7"),
  mimic("mimic-auricular-posterior", "Auricular posterior", "Grupo auricular", "Carece de valor funcional según el apunte.", "7"),
  mimic("mimic-platysma", "Platisma", "Grupo cervical", "Punto fijo proximal: asciende y tensa la piel del cuello. Punto fijo distal: deprime comisuras y piel del mentón.", "8"),
];

export const STUDY_ITEMS: StudyItem[] = [
  ...BONE_STUDY_ITEMS,
  ...regions,
  ...suturesAndFontanelles,
  ...foramina,
  ...atm,
  ...mastication,
  ...facialExpression,
];

export const CATEGORIES: Category[] = [
  "Huesos",
  "Regiones y cavidades",
  "Suturas y fontanelas",
  "Forámenes y conductos",
  "ATM",
  "Masticadores",
  "Mímica",
];

export const BONE_BY_ID = Object.fromEntries(BONE_DEFINITIONS.map((bone) => [bone.id, bone])) as Record<BoneId, BoneDefinition>;
export const ITEM_BY_ID = Object.fromEntries(STUDY_ITEMS.map((item) => [item.id, item])) as Record<string, StudyItem>;

export const MODEL_CENTER: Vec3 = [0, -86, 1528];

export const SOURCE_LINKS = [
  { name: "Apuntes de cátedra — Clase 1.a", detail: "Cráneo, ATM y músculos masticadores (archivo provisto por el usuario)." },
  { name: "Apuntes de cátedra — Clase 1.b", detail: "Músculos de la mímica (archivo provisto por el usuario)." },
  { name: "BodyParts3D", detail: "Geometría anatómica segmentada; CC BY-SA 2.1 Japan.", url: "https://dbarchive.biosciencedbc.jp/en/bodyparts3d/desc.html" },
  { name: "NCBI Bookshelf / StatPearls", detail: "Contraste del contenido neurovascular y notas complementarias.", url: "https://www.ncbi.nlm.nih.gov/books/NBK544352/" },
];
