import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Anatomía 3D · Cráneo",
    short_name: "Cráneo 3D",
    description: "Atlas 3D de cráneo, ATM y musculatura basado en apuntes de cátedra.",
    start_url: "/",
    display: "standalone",
    background_color: "#f4f2ee",
    theme_color: "#203b39",
    orientation: "any",
    lang: "es",
    icons: [
      { src: "/atlas-icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/atlas-icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
