"use client";

import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { CSS2DObject, CSS2DRenderer } from "three/examples/jsm/renderers/CSS2DRenderer.js";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { USDZExporter } from "three/examples/jsm/exporters/USDZExporter.js";
import { BONE_DEFINITIONS, MODEL_CENTER, type BoneId, type Vec3 } from "./anatomy-data";

export type CutPlane = "none" | "sagittal" | "coronal" | "transverse";
export type JawMovement = "none" | "depression" | "elevation" | "protrusion" | "retrusion" | "left" | "right" | "rotation" | "translation";
export type MuscleLayer = "none" | "mastication" | "mimic";

export interface SkullViewerHandle {
  setView: (view: "anterior" | "posterior" | "lateral" | "superior" | "inferior" | "reset") => void;
  focusBone: (boneId: BoneId) => void;
  exportAR: () => Promise<void>;
}

interface SkullViewerProps {
  selectedBone?: BoneId;
  hiddenBones: Set<BoneId>;
  transparentBones: Set<BoneId>;
  isolatedBone?: BoneId;
  explode: number;
  cutPlane: CutPlane;
  cutOffset: number;
  cutInverted: boolean;
  showLabels: boolean;
  marker?: Vec3;
  movement: JawMovement;
  animateMovement: boolean;
  muscleLayer: MuscleLayer;
  onSelectBone: (boneId: BoneId) => void;
  onLoadProgress?: (loaded: number, total: number) => void;
  onARStatus?: (status: string) => void;
}

const MODEL_PATH = "/models/skull/";
const defaultCamera = new THREE.Vector3(0, -360, 1535);

function materialFor(color: string) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.73,
    metalness: 0.02,
    side: THREE.DoubleSide,
  });
}

export const SkullViewer = forwardRef<SkullViewerHandle, SkullViewerProps>(function SkullViewer(
  {
    selectedBone,
    hiddenBones,
    transparentBones,
    isolatedBone,
    explode,
    cutPlane,
    cutOffset,
    cutInverted,
    showLabels,
    marker,
    movement,
    animateMovement,
    muscleLayer,
    onSelectBone,
    onLoadProgress,
    onARStatus,
  },
  ref,
) {
  const hostRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rootRef = useRef<THREE.Group | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const labelRendererRef = useRef<CSS2DRenderer | null>(null);
  const groupsRef = useRef(new Map<BoneId, THREE.Group>());
  const pivotsRef = useRef(new Map<BoneId, THREE.Vector3>());
  const labelsRef = useRef(new Map<BoneId, HTMLElement>());
  const markerRef = useRef<THREE.Group | null>(null);
  const muscleLayersRef = useRef(new Map<Exclude<MuscleLayer, "none">, THREE.Group>());
  const teethRef = useRef<{ upper?: THREE.Group; lower?: THREE.Group }>({});
  const raycasterRef = useRef(new THREE.Raycaster());
  const pointerRef = useRef(new THREE.Vector2());
  const onSelectRef = useRef(onSelectBone);
  const movementRef = useRef({ movement, animateMovement });
  const frameRef = useRef<number | null>(null);

  useEffect(() => {
    onSelectRef.current = onSelectBone;
  }, [onSelectBone]);

  useEffect(() => {
    movementRef.current = { movement, animateMovement };
  }, [movement, animateMovement]);

  useImperativeHandle(ref, () => ({
    setView(view) {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;
      const [cx, cy, cz] = MODEL_CENTER;
      const positions: Record<typeof view, THREE.Vector3> = {
        anterior: new THREE.Vector3(cx, cy - 305, cz + 4),
        posterior: new THREE.Vector3(cx, cy + 305, cz + 4),
        lateral: new THREE.Vector3(cx + 305, cy, cz + 4),
        superior: new THREE.Vector3(cx, cy, cz + 310),
        inferior: new THREE.Vector3(cx, cy, cz - 290),
        reset: defaultCamera.clone(),
      };
      camera.position.copy(positions[view]);
      controls.target.set(cx, cy, cz);
      controls.update();
    },
    focusBone(boneId) {
      const group = groupsRef.current.get(boneId);
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!group || !camera || !controls) return;
      const center = new THREE.Box3().setFromObject(group).getCenter(new THREE.Vector3());
      const direction = camera.position.clone().sub(controls.target).normalize();
      controls.target.copy(center);
      camera.position.copy(center.clone().add(direction.multiplyScalar(125)));
      controls.update();
    },
    async exportAR() {
      const root = rootRef.current;
      if (!root) return;
      try {
        onARStatus?.("Preparando el modelo para AR…");
        const exportScene = new THREE.Scene();
        const clone = root.clone(true);
        clone.position.set(-MODEL_CENTER[0], -MODEL_CENTER[1], -MODEL_CENTER[2]);
        clone.scale.setScalar(0.001);
        clone.traverse((object) => {
          if (object instanceof THREE.Mesh) {
            const current = object.material as THREE.MeshStandardMaterial;
            object.material = current.clone();
            object.material.clippingPlanes = [];
            object.material.emissive.set(0x000000);
          }
        });
        exportScene.add(clone);
        const exporter = new USDZExporter();
        const data = await exporter.parseAsync(exportScene, { quickLookCompatible: true });
        const url = URL.createObjectURL(new Blob([data], { type: "model/vnd.usdz+zip" }));
        const link = document.createElement("a");
        link.rel = "ar";
        link.href = url;
        link.download = "craneo-adulto.usdz";
        const preview = document.createElement("img");
        preview.alt = "Abrir cráneo en realidad aumentada";
        link.append(preview);
        document.body.append(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 90_000);
        onARStatus?.("Si iOS no abrió Quick Look, revisá la descarga del archivo USDZ.");
      } catch (error) {
        console.error(error);
        onARStatus?.("No se pudo generar el archivo AR en este navegador.");
      }
    },
  }), [onARStatus]);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf5f3ef);
    scene.fog = new THREE.Fog(0xf5f3ef, 360, 720);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 1800);
    camera.position.copy(defaultCamera);
    camera.up.set(0, 0, 1);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.localClippingEnabled = true;
    renderer.domElement.className = "skull-canvas";
    host.append(renderer.domElement);
    rendererRef.current = renderer;

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.className = "skull-label-layer";
    labelRenderer.domElement.style.position = "absolute";
    labelRenderer.domElement.style.inset = "0";
    labelRenderer.domElement.style.pointerEvents = "none";
    host.append(labelRenderer.domElement);
    labelRendererRef.current = labelRenderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(...MODEL_CENTER);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 78;
    controls.maxDistance = 560;
    controls.zoomToCursor = true;
    controls.update();
    controlsRef.current = controls;

    scene.add(new THREE.HemisphereLight(0xfffbf5, 0x6c7882, 2.5));
    const key = new THREE.DirectionalLight(0xffffff, 3.4);
    key.position.set(-160, -260, 300);
    key.castShadow = true;
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xbfd8ff, 2.2);
    rim.position.set(210, 130, 160);
    scene.add(rim);

    const platform = new THREE.Mesh(
      new THREE.CircleGeometry(126, 96),
      new THREE.MeshStandardMaterial({ color: 0xe9e5df, roughness: 1, transparent: true, opacity: 0.72 }),
    );
    platform.rotation.x = Math.PI / 2;
    platform.position.set(0, -84, 1411);
    platform.receiveShadow = true;
    scene.add(platform);

    const root = new THREE.Group();
    root.name = "Cráneo adulto segmentado";
    scene.add(root);
    rootRef.current = root;
    const groups = groupsRef.current;
    const labels = labelsRef.current;
    const pivots = pivotsRef.current;
    const muscleLayers = muscleLayersRef.current;

    const loader = new OBJLoader();

    const toothMaterial = new THREE.MeshStandardMaterial({ color: 0xf4ead9, roughness: 0.62 });
    const upperTeeth = new THREE.Group();
    upperTeeth.name = "Dentición superior esquemática";
    const lowerTeeth = new THREE.Group();
    lowerTeeth.name = "Dentición inferior esquemática";
    const arch = [
      { x: 4, y: -184, r: 2.7, l: 8.5 },
      { x: 10, y: -182, r: 2.8, l: 8.3 },
      { x: 17, y: -177, r: 2.9, l: 9.2 },
      { x: 25, y: -169, r: 3.2, l: 8.0 },
      { x: 32, y: -159, r: 3.3, l: 7.8 },
      { x: 39, y: -148, r: 3.8, l: 7.1 },
      { x: 44, y: -136, r: 4.0, l: 6.8 },
      { x: 47, y: -124, r: 3.8, l: 6.3 },
    ];
    ([-1, 1] as const).forEach((side) => arch.forEach((tooth, index) => {
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(tooth.r, tooth.l, 3, 8), toothMaterial.clone());
      upper.rotation.x = Math.PI / 2;
      upper.position.set(side * tooth.x, tooth.y, 1475 - index * 0.2);
      upper.userData.boneId = side < 0 ? "maxilla-r" : "maxilla-l";
      upper.castShadow = true;
      upperTeeth.add(upper);
      const lower = new THREE.Mesh(new THREE.CapsuleGeometry(tooth.r * 0.95, tooth.l * 0.92, 3, 8), toothMaterial.clone());
      lower.rotation.x = Math.PI / 2;
      lower.position.set(side * tooth.x, tooth.y + 2, 1492 + index * 0.15);
      lower.userData.boneId = "mandible";
      lower.castShadow = true;
      lowerTeeth.add(lower);
    }));
    root.add(upperTeeth, lowerTeeth);
    teethRef.current = { upper: upperTeeth, lower: lowerTeeth };

    const makeTube = (name: string, points: Vec3[], color: number, radius = 2.7) => {
      const curve = new THREE.CatmullRomCurve3(points.map((point) => new THREE.Vector3(...point)));
      const mesh = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 18, radius, 8, false),
        new THREE.MeshStandardMaterial({ color, roughness: 0.76, transparent: true, opacity: 0.92, depthWrite: false }),
      );
      mesh.name = name;
      mesh.renderOrder = 4;
      const label = document.createElement("div");
      label.className = "muscle-label";
      label.textContent = name;
      const labelObject = new CSS2DObject(label);
      labelObject.position.copy(curve.getPoint(0.52));
      const container = new THREE.Group();
      container.add(mesh, labelObject);
      return container;
    };

    const masticationLayer = new THREE.Group();
    masticationLayer.name = "Esquema topográfico de músculos masticadores";
    ([-1, 1] as const).forEach((side) => {
      masticationLayer.add(
        makeTube("Masetero", [[side * 48, -139, 1530], [side * 54, -121, 1490], [side * 48, -101, 1444]], 0xb84d38, 5.4),
        makeTube("Temporal", [[side * 40, -106, 1598], [side * 54, -117, 1558], [side * 43, -136, 1498]], 0xd06d45, 5.1),
        makeTube("Pterigoideo lateral", [[side * 19, -118, 1527], [side * 31, -108, 1516], [side * 45, -91, 1502]], 0x865345, 3.7),
        makeTube("Pterigoideo medial", [[side * 18, -120, 1514], [side * 29, -108, 1481], [side * 42, -99, 1446]], 0x9f654e, 4.4),
      );
    });
    masticationLayer.visible = false;
    root.add(masticationLayer);
    muscleLayers.set("mastication", masticationLayer);

    const mimicLayer = new THREE.Group();
    mimicLayer.name = "Esquema topográfico de músculos de la mímica";
    ([-1, 1] as const).forEach((side) => {
      mimicLayer.add(
        makeTube("Occipitofrontal", [[side * 22, -174, 1562], [side * 27, -161, 1605], [side * 30, -138, 1630]], 0xc75b48, 3.7),
        makeTube("Corrugador", [[side * 8, -190, 1551], [side * 20, -188, 1555], [side * 30, -182, 1554]], 0x9f4a3f, 2.1),
        makeTube("Orbicular del ojo", [[side * 9, -192, 1535], [side * 28, -195, 1547], [side * 44, -190, 1534], [side * 28, -196, 1519], [side * 9, -192, 1535]], 0xb95d4d, 2.5),
        makeTube("Nasal", [[side * 5, -195, 1524], [side * 12, -197, 1514], [side * 18, -192, 1507]], 0xd0785a, 2.0),
        makeTube("Elevador labial", [[side * 17, -195, 1515], [side * 22, -197, 1495], [side * 19, -196, 1485]], 0xc56549, 2.1),
        makeTube("Cigomático menor", [[side * 43, -184, 1520], [side * 33, -195, 1502], [side * 23, -197, 1487]], 0xd77b58, 2.2),
        makeTube("Cigomático mayor", [[side * 49, -180, 1508], [side * 38, -192, 1491], [side * 27, -197, 1478]], 0xc35743, 2.7),
        makeTube("Risorio", [[side * 53, -181, 1480], [side * 39, -193, 1478], [side * 26, -198, 1476]], 0xb96652, 2.0),
        makeTube("Buccinador", [[side * 50, -178, 1490], [side * 47, -186, 1470], [side * 28, -195, 1472]], 0xa95142, 3.3),
        makeTube("Depresor del ángulo", [[side * 26, -196, 1475], [side * 31, -193, 1455], [side * 36, -185, 1445]], 0x8f5146, 2.2),
        makeTube("Depresor labial", [[side * 18, -198, 1472], [side * 17, -197, 1454], [side * 21, -191, 1447]], 0xb25a48, 2.1),
        makeTube("Mentoniano", [[side * 12, -198, 1465], [side * 9, -199, 1449], [side * 6, -195, 1442]], 0xd0795c, 2.4),
      );
    });
    mimicLayer.add(
      makeTube("Prócer", [[0, -195, 1540], [0, -199, 1528], [0, -198, 1518]], 0xa94e42, 2.3),
      makeTube("Orbicular de la boca", [[-26, -198, 1477], [0, -202, 1485], [26, -198, 1477], [0, -202, 1468], [-26, -198, 1477]], 0xb94f43, 2.7),
      makeTube("Platisma", [[-46, -174, 1448], [0, -180, 1418], [46, -174, 1448]], 0xaa6754, 3.2),
    );
    mimicLayer.visible = false;
    root.add(mimicLayer);
    muscleLayers.set("mimic", mimicLayer);
    let loaded = 0;
    const total = BONE_DEFINITIONS.reduce((sum, bone) => sum + bone.files.length, 0);
    const pendingByBone = new Map<BoneId, number>();
    const rawByBone = new Map<BoneId, THREE.Object3D[]>();

    BONE_DEFINITIONS.forEach((bone) => {
      pendingByBone.set(bone.id, bone.files.length);
      rawByBone.set(bone.id, []);
      bone.files.forEach((file) => {
        loader.load(
          `${MODEL_PATH}${file}`,
          (object) => {
            object.traverse((child) => {
              if (child instanceof THREE.Mesh) {
                child.geometry.computeVertexNormals();
                child.material = materialFor(bone.color);
                child.castShadow = true;
                child.receiveShadow = true;
                child.userData.boneId = bone.id;
              }
            });
            rawByBone.get(bone.id)?.push(object);
            pendingByBone.set(bone.id, (pendingByBone.get(bone.id) ?? 1) - 1);
            loaded += 1;
            onLoadProgress?.(loaded, total);

            if (pendingByBone.get(bone.id) === 0) {
              const objects = rawByBone.get(bone.id) ?? [];
              const bounds = new THREE.Box3();
              objects.forEach((item) => bounds.expandByObject(item));
              const center = bounds.getCenter(new THREE.Vector3());
              const pivot = bone.id === "mandible" ? new THREE.Vector3(0, -90, 1500) : center.clone();
              const group = new THREE.Group();
              group.name = bone.name;
              group.userData.boneId = bone.id;
              group.position.copy(pivot);
              objects.forEach((item) => {
                item.position.sub(pivot);
                group.add(item);
              });
              root.add(group);
              if (bone.id === "mandible") group.attach(lowerTeeth);
              groups.set(bone.id, group);
              pivots.set(bone.id, pivot.clone());

              const label = document.createElement("div");
              label.className = "bone-label";
              label.textContent = bone.name;
              const labelObject = new CSS2DObject(label);
              labelObject.position.copy(center.clone().sub(pivot));
              group.add(labelObject);
              labels.set(bone.id, label);
            }
          },
          undefined,
          (error) => {
            console.error(`No se pudo cargar ${file}`, error);
            loaded += 1;
            onLoadProgress?.(loaded, total);
          },
        );
      });
    });

    const markerGroup = new THREE.Group();
    const dot = new THREE.Mesh(
      new THREE.SphereGeometry(2.8, 20, 20),
      new THREE.MeshStandardMaterial({ color: 0xd56838, emissive: 0x7f2410, emissiveIntensity: 0.5 }),
    );
    const halo = new THREE.Mesh(
      new THREE.RingGeometry(5.6, 7.4, 32),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, side: THREE.DoubleSide }),
    );
    halo.rotation.x = Math.PI / 2;
    markerGroup.add(dot, halo);
    markerGroup.visible = false;
    scene.add(markerGroup);
    markerRef.current = markerGroup;

    const resize = () => {
      const width = host.clientWidth;
      const height = host.clientHeight;
      camera.aspect = Math.max(width / Math.max(height, 1), 0.1);
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
      labelRenderer.setSize(width, height);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    resize();

    let pointerDown = { x: 0, y: 0 };
    const handlePointerDown = (event: PointerEvent) => {
      pointerDown = { x: event.clientX, y: event.clientY };
    };
    const handlePointerUp = (event: PointerEvent) => {
      if (Math.hypot(event.clientX - pointerDown.x, event.clientY - pointerDown.y) > 7) return;
      const bounds = renderer.domElement.getBoundingClientRect();
      pointerRef.current.set(
        ((event.clientX - bounds.left) / bounds.width) * 2 - 1,
        -((event.clientY - bounds.top) / bounds.height) * 2 + 1,
      );
      raycasterRef.current.setFromCamera(pointerRef.current, camera);
      const hits = raycasterRef.current.intersectObjects(Array.from(groupsRef.current.values()), true);
      const hit = hits.find((candidate) => candidate.object.userData.boneId);
      if (hit?.object.userData.boneId) onSelectRef.current(hit.object.userData.boneId as BoneId);
    };
    renderer.domElement.addEventListener("pointerdown", handlePointerDown);
    renderer.domElement.addEventListener("pointerup", handlePointerUp);

    const clock = new THREE.Clock();
    const animate = () => {
      const elapsed = clock.getElapsedTime();
      const mandible = groupsRef.current.get("mandible");
      const mandiblePivot = pivotsRef.current.get("mandible");
      if (mandible && mandiblePivot) {
        const state = movementRef.current;
        const amount = state.animateMovement ? (Math.sin(elapsed * 1.7 - Math.PI / 2) + 1) / 2 : 1;
        mandible.rotation.set(0, 0, 0);
        mandible.position.copy(mandiblePivot);
        switch (state.movement) {
          case "depression":
            mandible.rotation.x = 0.4 * amount;
            mandible.position.y -= 8 * amount;
            mandible.position.z -= 7 * amount;
            break;
          case "elevation":
            mandible.rotation.x = 0.4 * (1 - amount);
            mandible.position.y -= 8 * (1 - amount);
            mandible.position.z -= 7 * (1 - amount);
            break;
          case "protrusion":
            mandible.position.y -= 13 * amount;
            break;
          case "retrusion":
            mandible.position.y += 7 * amount;
            break;
          case "left":
            mandible.position.x -= 10 * amount;
            mandible.rotation.z = -0.035 * amount;
            break;
          case "right":
            mandible.position.x += 10 * amount;
            mandible.rotation.z = 0.035 * amount;
            break;
          case "rotation":
            mandible.rotation.x = 0.22 * amount;
            break;
          case "translation":
            mandible.position.y -= 18 * amount;
            mandible.position.z -= 3 * amount;
            break;
        }
      }
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      observer.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", handlePointerDown);
      renderer.domElement.removeEventListener("pointerup", handlePointerUp);
      root.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
      labelRenderer.domElement.remove();
      groups.clear();
      labels.clear();
      pivots.clear();
      muscleLayers.clear();
      teethRef.current = {};
    };
  }, [onLoadProgress]);

  useEffect(() => {
    groupsRef.current.forEach((group, boneId) => {
      const hidden = hiddenBones.has(boneId) || Boolean(isolatedBone && isolatedBone !== boneId);
      group.visible = !hidden;
      group.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        const material = object.material as THREE.MeshStandardMaterial;
        const transparent = transparentBones.has(boneId) && !isolatedBone;
        material.transparent = transparent;
        material.opacity = transparent ? 0.22 : 1;
        material.depthWrite = !transparent;
        material.emissive.set(boneId === selectedBone ? 0x52200e : 0x000000);
        material.emissiveIntensity = boneId === selectedBone ? 0.42 : 0;
      });
      const label = labelsRef.current.get(boneId);
      if (label) {
        label.style.display = showLabels && !hidden ? "block" : "none";
        label.dataset.selected = String(boneId === selectedBone);
      }
    });
    if (teethRef.current.upper) {
      teethRef.current.upper.visible = (!isolatedBone || isolatedBone === "maxilla-r" || isolatedBone === "maxilla-l") && !(hiddenBones.has("maxilla-r") && hiddenBones.has("maxilla-l"));
    }
  }, [hiddenBones, transparentBones, isolatedBone, selectedBone, showLabels]);

  useEffect(() => {
    groupsRef.current.forEach((group, boneId) => {
      if (boneId === "mandible") return;
      const pivot = pivotsRef.current.get(boneId);
      if (!pivot) return;
      const direction = pivot.clone().sub(new THREE.Vector3(...MODEL_CENTER));
      if (direction.lengthSq() < 1) direction.set(0, -1, 0);
      direction.normalize();
      group.position.copy(pivot).add(direction.multiplyScalar(explode * 0.7));
    });
  }, [explode]);

  useEffect(() => {
    const sign = cutInverted ? -1 : 1;
    let plane: THREE.Plane | null = null;
    if (cutPlane === "sagittal") plane = new THREE.Plane(new THREE.Vector3(sign, 0, 0), cutOffset);
    if (cutPlane === "coronal") plane = new THREE.Plane(new THREE.Vector3(0, sign, 0), sign * (86 + cutOffset));
    if (cutPlane === "transverse") plane = new THREE.Plane(new THREE.Vector3(0, 0, sign), sign * (-1528 + cutOffset));
    groupsRef.current.forEach((group) => {
      group.traverse((object) => {
        if (object instanceof THREE.Mesh) (object.material as THREE.MeshStandardMaterial).clippingPlanes = plane ? [plane] : [];
      });
    });
  }, [cutPlane, cutOffset, cutInverted]);

  useEffect(() => {
    if (!markerRef.current) return;
    markerRef.current.visible = Boolean(marker);
    if (marker) markerRef.current.position.set(...marker);
  }, [marker]);

  useEffect(() => {
    muscleLayersRef.current.forEach((layer, id) => {
      layer.visible = muscleLayer === id;
    });
  }, [muscleLayer]);

  return (
    <div ref={hostRef} className="skull-viewer" role="img" aria-label="Modelo 3D interactivo de un cráneo adulto segmentado">
      <div className="viewer-help">Arrastrá para rotar · Pellizcá para zoom · Tocá un hueso</div>
    </div>
  );
});
