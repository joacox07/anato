import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Anatomía 3D · Cráneo",
  description: "Atlas 3D interactivo para estudiar cráneo, ATM y musculatura según apuntes de cátedra.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Cráneo 3D",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/atlas-icon.svg",
    shortcut: "/atlas-icon.svg",
    apple: "/atlas-icon-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
